export class UI {
    constructor(game) {
        this.game = game;
        this.fontSize = 30;
        this.fontFamily = 'Helvetica';
        this.livesImage = document.getElementById('lives');
        this.level = 1;
    }
    draw(ctx) {
        ctx.save();
        ctx.shadowOffsetX = 2;
        ctx.shadowOffsetY = 2;
        ctx.shadowColor = 'white';
        ctx.shadowBlur = 0;
        ctx.font = this.fontSize + 'px ' + this.fontFamily;
        ctx.textAlign = 'left';
        ctx.fillStyle = this.game.fontColor;

     // TELA DE MENU
        if (!this.game.gameStart) {
            ctx.textAlign = 'center';
            ctx.fillStyle = 'black';
            
            ctx.font = this.fontSize * 2 + 'px ' + this.fontFamily;
            ctx.fillText('MENU INICIAL', this.game.width * 0.5, this.game.height * 0.3);
            
            ctx.font = this.fontSize * 0.8 + 'px ' + this.fontFamily;
            ctx.fillText('Pressione 1 para FÁCIL', this.game.width * 0.5, this.game.height * 0.5);
            ctx.fillText('Pressione 2 para MÉDIO', this.game.width * 0.5, this.game.height * 0.6);
            ctx.fillText('Pressione 3 para DIFÍCIL', this.game.width * 0.5, this.game.height * 0.7);
            
            ctx.restore();
            return;
        }

        // score
        ctx.fillText('Pontuação: ' + this.game.score, 20, 50);

        // time
        const formattedTime = (this.game.time * 0.001).toFixed(1);
        ctx.fillText('Tempo: ' + formattedTime, 20, 80);

        // vidas
        for (let i = 0; i < this.game.lives; i++) {
            ctx.drawImage(this.livesImage, 25 * i + 20, 95, 25, 25);
        }

        let currentLevel = this.game.level || 1; 

        ctx.save(); // Salva estado atual
        ctx.textAlign = 'right'; // Alinha direita
        ctx.lineWidth = 3;
        ctx.strokeStyle = 'orange'; // Cor da borda
        ctx.fillStyle = 'red';  // Cor do texto
        
        let xPos = this.game.width - 20;
        
        // Desenha Borda e depois o Texto
        ctx.strokeText('Nível: ' + currentLevel, xPos, 50);
        ctx.fillText('Nível: ' + currentLevel, xPos, 50);
        ctx.restore(); // Restaura estado


        //pisca
        if (this.game.showLevelUp) {
            // cada 100ms alterna
            if (Math.floor(this.game.levelUpTimer / 100) % 2 === 0) {
                ctx.save();
                ctx.textAlign = 'center';
                ctx.font = (this.fontSize * 2) + 'px ' + this.fontFamily;
                
                // Borda grossa
                ctx.lineWidth = 5;
                ctx.strokeStyle = 'white';
                ctx.strokeText('LEVEL UP!', this.game.width * 0.5, this.game.height * 0.5);
                
                // Texto colorido
                ctx.fillStyle = 'yellow';
                ctx.fillText('LEVEL UP!', this.game.width * 0.5, this.game.height * 0.5);
                ctx.restore();
            }
        }

        // game over
        if (this.game.gameOver) {
            ctx.textAlign = 'center';
            ctx.font = this.fontSize * 2 + 'px ' + this.fontFamily;
            if (this.game.score > this.game.winningScore) {
                ctx.fillText('Boo-yah', this.game.width * 0.5, this.game.height * 0.5 - 20);
                ctx.font = this.fontSize * 0.7 + 'px ' + this.fontFamily;
                ctx.fillText('Com medo do que?', this.game.width * 0.5, this.game.height * 0.5 + 20);
            } else {
                ctx.fillText('GAME OVER', this.game.width * 0.5, this.game.height * 0.5 - 20);
                ctx.font = this.fontSize * 0.7 + 'px ' + this.fontFamily;
                ctx.fillText('Melhor sorte na próxima', this.game.width * 0.5, this.game.height * 0.5 + 20);
            }
        }
        ctx.restore();
    }
}