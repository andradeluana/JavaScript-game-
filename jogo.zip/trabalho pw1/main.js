import {
    Player
} from './player.js';
import {
    InputHandler
} from './input.js';
import {
    Background
} from './background.js';
import {
    FlyingEnemy,
    ClimbingEnemy,
    GroundEnemy
} from './enemies.js';
import {
    UI
} from './UI.js';

window.addEventListener('load', () => {
    const canvas = document.getElementById('canvas1');
    const ctx = canvas.getContext('2d');
    canvas.width = 900;
    canvas.height = 500;

    class Game {
        constructor(width, height) {
            this.width = width;
            this.height = height;
            this.groundMargin = 80;
            this.speed = 0;
            this.maxSpeed = 4;

            this.level = 1;
            this.showLevelUp = false;
            this.levelUpTimer = 0; // tempo da msg

            this.background = new Background(this);
            this.player = new Player(this);
            this.input = new InputHandler(this);
            this.UI = new UI(this);

            this.enemies = [];
            this.particles = [];
            this.collisions = [];

            this.enemyTimer = 0;
            this.enemyInterval = 1000;

            this.maxParticles = 200;
            this.debug = false;
            this.score = 0;
            this.fontColor = 'black';
            this.time = 0;
            this.winningScore = 25;
            this.maxTime = 30000; // 30s
            this.gameOver = false;
            this.lives = 5;
            this.gameStart = false; //começa pausado

            // estado inicial do player
            this.player.currentState = this.player.states[0];
            this.player.currentState.enter();

            // áudio
            this.audio = {
                boom: document.getElementById('boom_sfx'),
                started: false,
                start() {
                    if (this.started || !this.boom) return;
                    this.started = true;
                    this.boom.play().then(() => {
                        this.boom.pause();
                        this.boom.currentTime = 0;
                    }).catch(() => {});
                },
                playBoom() {
                    if (!this.boom) return;
                    const sfx = this.boom.cloneNode();
                    sfx.volume = 0.9;
                    sfx.play().catch(() => {});
                }
            };
        }


        update(deltaTime) {
            if (!this.gameStart) {

                if (this.input.keys.includes('1')) {
                    this.lives = 10;
                    this.winningScore = 10;
                    this.enemyInterval = 2000; // Inimigos demoram mais
                    this.gameStart = true;
                    this.level =1;
                }

                else if (this.input.keys.includes('2')) {
                    this.lives = 5;
                    this.winningScore = 25;
                    this.enemyInterval = 1000;
                    this.gameStart = true;
                    this.level= 1;
                }

                else if (this.input.keys.includes('3')) {
                    this.lives = 2;
                    this.winningScore = 50;
                    this.enemyInterval = 500;
                    this.gameStart = true;
                    this.level = 1;

                }
                return; // Não executa o resto enquanto não escolher
            }
            let currentLevel = 1;
            if (this.score >= 5) currentLevel = 2;
            if (this.score >= 10) currentLevel = 3;

            // if muda nível (ex: estava no 1 e foi para o 2)
            if (currentLevel > this.level) {
                this.level = currentLevel;
                this.showLevelUp = true;
                this.levelUpTimer = 0;

                // Dificuldade Progressiva
                if (this.level === 2) {
                    this.enemyInterval = 600; // Mais inimigos
                    this.maxSpeed = 6;    
                } else if (this.level === 3) {
                    this.enemyInterval = 300; // Caos total
                    this.maxSpeed = 8;        // Muito rápido
                }
            }

            // Timer da mensagem "LEVEL UP!"
            if (this.showLevelUp) {
                this.levelUpTimer += deltaTime;
                if (this.levelUpTimer > 2000) { //2s
                    this.showLevelUp = false;
                }
            }

            this.time += deltaTime;
            if (this.time > this.maxTime) this.gameOver = true;

            this.background.update();
            this.player.update(this.input.keys, deltaTime);

            if (this.enemyTimer > this.enemyInterval) {
                this.addEnemy();
                this.enemyTimer = 0;
            } else {
                this.enemyTimer += deltaTime;
            }

            this.enemies.forEach(e => e.update(deltaTime));
            this.particles.forEach(p => p.update(deltaTime));
            this.collisions.forEach(c => c.update(deltaTime));

            if (this.particles.length > this.maxParticles) {
                this.particles.length = this.maxParticles;
            }

            this.enemies = this.enemies.filter(e => !e.markedForDeletion);
            this.particles = this.particles.filter(p => !p.markedForDeletion);
            this.collisions = this.collisions.filter(c => !c.markedForDeletion);
        }

        draw(context) {
            this.background.draw(context);
            this.player.draw(context);
            this.enemies.forEach(e => e.draw(context));
            this.particles.forEach(p => p.draw(context));
            this.collisions.forEach(c => c.draw(context));
            this.UI.draw(context);
        }

        addEnemy() {
            if (this.speed > 0 && Math.random() < 0.5) this.enemies.push(new GroundEnemy(this));
            else if (this.speed > 0) this.enemies.push(new ClimbingEnemy(this));
            this.enemies.push(new FlyingEnemy(this));
        }
    }

    const game = new Game(canvas.width, canvas.height);
    let lastTime = 0;

    function animate(timeStamp) {
        const deltaTime = timeStamp - lastTime;
        lastTime = timeStamp;
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        game.update(deltaTime);
        game.draw(ctx);
        if (!game.gameOver) requestAnimationFrame(animate);
    }
    animate(0);
});